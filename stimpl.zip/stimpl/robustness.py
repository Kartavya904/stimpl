from stimpl.test import check_equal, check_run_result, check_program_raises
from stimpl.runtime import run_stimpl
from stimpl.types import *
from stimpl.expression import *


def run_stimpl_robustness_tests():
    pass
